﻿using LetenkyParser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;

namespace AkcniLetenkyApi.Controllers
{
    public class TitlesController : ApiController
    {


        public TitlesController()
        {
        }

        public IEnumerable<Title> GetAllTitles()
        {
            return TitleDownloader.Instance.Titles.OrderByDescending(t => t.Date);
        }

        public IEnumerable<Title> GetTitlesFromDate(DateTime date)
        {
            return TitleDownloader.Instance.Titles.Where(t => t.Date > date).OrderByDescending(t => t.Date);
        }
    }
}
